package com.chatlog.exception;

import javax.xml.bind.ValidationException;

public class NullFieldException extends ValidationException {
	
	public NullFieldException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	private static final long serialVersionUID = 1L;
}

