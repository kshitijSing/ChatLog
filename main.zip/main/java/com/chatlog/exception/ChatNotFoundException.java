package com.chatlog.exception;

public class ChatNotFoundException extends Exception {

	public ChatNotFoundException() {
		super();
	}

	public ChatNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public ChatNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public ChatNotFoundException(String message) {
		super(message);
	}

	public ChatNotFoundException(Throwable cause) {
		super(cause);
	}
}
