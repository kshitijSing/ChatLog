package com.chatlog.model;

import javax.persistence.*;


@Entity
@Table(name="CHATLOGUSERS")
public class ChatLogUser {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int messageId;
	@Column(name = "message")
	private String message;
	@Column(name = "user_name")
	private String user;
	@Column(name = "timestamp")
	private Long timestamp;
	@Column(name = "msg_status")
	private boolean isSent;
	public int getMessageId() {
		return messageId;
	}
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
	public boolean isSent() {
		return isSent;
	}
	public void setSent(boolean isSent) {
		this.isSent = isSent;
	}
}
