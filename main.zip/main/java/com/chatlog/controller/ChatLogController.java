package com.chatlog.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chatlog.action.ChatLogAction;
import com.chatlog.exception.ChatNotFoundException;
import com.chatlog.exception.NullFieldException;
import com.chatlog.model.ChatLogUser;
import com.chatlog.service.ChatLogService;

@RestController
@RequestMapping("chatlogs/")
public class ChatLogController {

	@Autowired
	ChatLogService chatLogService;

	/*
	 * Add a new chat
	 */
	@PostMapping(value = "/{user}")
	public ResponseEntity<String> addChatLogData(@PathVariable(value = "user") String user,
			@RequestBody ChatLogAction chatLogAction) {
		try {
			chatLogService.createChatLog(chatLogAction, user);
		} catch (NullFieldException e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			return new ResponseEntity<String>("Something is wrong.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<String>("Added Successfully!!!", HttpStatus.OK);
	}

	/*
	 * Get all the chats of a particular user
	 */
	@GetMapping(value = "/{user}")
	public List<ChatLogUser> getUserAllChatLog(@PathVariable(value = "user") String user,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "10") Integer pageSize) {
		return chatLogService.getAllChatLog(user, pageNo, pageSize);
	}

	/*
	 * Delete all the chats of an user
	 */
	@DeleteMapping(value = "/{user}")
	@Transactional
	public ResponseEntity<String> deleteUserChatLog(@PathVariable(value = "user") String user)
			throws NullFieldException {
		chatLogService.deleteUserChat(user);
		return new ResponseEntity<String>("Delete Successfully!!!", HttpStatus.OK);
	}

	/*
	 * Delete chat of an user by message ID
	 */
	@DeleteMapping(value = "/{user}/{message_id}")
	public ResponseEntity<String> deleteChatByUserAndMsgId(@PathVariable(value = "user") String user,
			@PathVariable(value = "message_id") String messageId) throws ChatNotFoundException {
		chatLogService.deleteChatByMsgID(user, messageId);
		return new ResponseEntity<String>("Delete Successfully!!!", HttpStatus.OK);
	}
}
