package com.chatlog.service;

import java.util.List;

import com.chatlog.action.ChatLogAction;
import com.chatlog.model.*;
import com.chatlog.exception.ChatNotFoundException;
import com.chatlog.exception.NullFieldException;


public interface ChatLogService {

	void createChatLog(ChatLogAction chatLogAction, String user) throws NullFieldException;

	List<ChatLogUser> getAllChatLog(String user, int pageNo, int pageSize);

	void deleteChatByMsgID(String user, String messageId) throws ChatNotFoundException;

	void deleteUserChat(String user) throws NullFieldException;

}