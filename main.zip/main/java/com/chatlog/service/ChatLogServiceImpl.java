package com.chatlog.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import com.chatlog.action.ChatLogAction;
import com.chatlog.exception.ChatNotFoundException;
import com.chatlog.exception.NullFieldException;
import com.chatlog.model.ChatLogUser;
import com.chatlog.repo.ChatLogRepo;

@Service
public class ChatLogServiceImpl implements ChatLogService {

	
	@Autowired
	private ChatLogRepo chatLogRepo;
	

	/*
	 * This method will create a new entry in DataBase
	 */
	@Override
	public void createChatLog(ChatLogAction chatLogAction, String user) throws NullFieldException {
		isValidUser(user);
		validateChatLogData(chatLogAction);
		ChatLogUser chatLogUser = convertToEntity(chatLogAction, user);
		chatLogUser = chatLogRepo.save(chatLogUser);
	}
	
	/*
	 * Method will return the list of chats by specific user
	 */
	@Override
	public List<ChatLogUser> getAllChatLog(String user, int pageNo, int pageSize) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by("timestamp").descending());
		Page<ChatLogUser> chatLogUserList = null;
		chatLogUserList = chatLogRepo.findAllByUser(user, paging);

		if (chatLogUserList != null && chatLogUserList.hasContent()) {
			return chatLogUserList.getContent();
		}
		return new ArrayList<>();
	}


	private void validateChatLogData(ChatLogAction chatLogAction) throws NullFieldException {
		if (ObjectUtils.isEmpty(chatLogAction.getMessage())) {
			throw new NullFieldException("Please enter a message");
		}
		if (ObjectUtils.isEmpty(chatLogAction.getTimestamp())) {
			throw new NullFieldException("Timestamp can not be null or empty");
		}
	}

	@Override
	public void deleteUserChat(String user) throws NullFieldException {
		isValidUser(user);
		chatLogRepo.deleteByUser(user);
	}

	@Override
	@Transactional
	public void deleteChatByMsgID(String user, String messageId) throws ChatNotFoundException {
		int id = Integer.valueOf(messageId);
		chatLogRepo.deleteById(id); 
	}
	
	/*
	 * Method to check if user is valid or not null
	 */
	private void isValidUser(String user) throws NullFieldException {
		if (StringUtils.isEmpty(user)) {
			throw new NullFieldException("User can not be null/empty");
		}
	}
	

	/*
	 * Method to set data in ChatLogUser object so we it can be inserted in DataBase
	 */
	private ChatLogUser convertToEntity(ChatLogAction chatLogAction, String user) {
		ChatLogUser chatLogUser = new ChatLogUser();
		chatLogUser.setMessage(chatLogAction.getMessage());
		chatLogUser.setUser(user);
		chatLogUser.setTimestamp(chatLogAction.getTimestamp());
		chatLogUser.setSent(chatLogAction.isSent());
		return chatLogUser;
	}

}
