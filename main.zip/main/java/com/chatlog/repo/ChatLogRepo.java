package com.chatlog.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.chatlog.model.ChatLogUser;

public interface ChatLogRepo extends JpaRepository<ChatLogUser, Integer> {

	Page<ChatLogUser> findAllByUser(String user, Pageable paging);

	void deleteByUser(String user);
	
}
